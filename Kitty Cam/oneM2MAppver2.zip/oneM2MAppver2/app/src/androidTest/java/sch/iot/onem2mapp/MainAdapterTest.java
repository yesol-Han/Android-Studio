package sch.iot.onem2mapp;

import static org.junit.Assert.*;

public class MainAdapterTest {

}