package sch.iot.onem2mapp;

public class ListViewItem {

    private String name;
    private String videourl;

    public ListViewItem (String name, String videourl){
        this.name = name;
        this.videourl = videourl;
    }

    public String getName() {
        return name;
    }
    public String getVideoUrl(){
        return videourl;
    }

    //나중에 수정한다면 사용
    public void setName(String name) {
        this.name = name;
    }
    public void setVideoUrl(String videourl) {
        this.videourl = videourl;
    }

}
