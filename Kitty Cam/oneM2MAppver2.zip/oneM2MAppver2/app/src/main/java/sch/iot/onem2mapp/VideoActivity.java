package sch.iot.onem2mapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class VideoActivity extends AppCompatActivity {
    private TextView name;
    private VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        videoView = findViewById(R.id.video);
        name = findViewById(R.id.videoname);

        Intent intent = getIntent();
        videoView.setVideoURI(Uri.parse(intent.getStringExtra("videourl")));
        name.setText(intent.getStringExtra("videoname"));

        MediaController mc = new MediaController(this);
        videoView.setMediaController(mc);
        videoView.requestFocus();

        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                /*Intent intent = new Intent();   *//*새 화면 추가하기*//*
                setResult(RESULT_OK, intent);*/
                finish();
            }
        });
    }

}
